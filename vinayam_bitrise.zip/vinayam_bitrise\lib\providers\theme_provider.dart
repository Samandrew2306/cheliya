import 'package:flutter/material.dart';
import 'package:google_fonts.dart';
import 'package:shared_preferences.dart';

class ThemeProvider with ChangeNotifier {
  ThemeData _currentTheme;
  String _currentFont = 'Roboto';
  final SharedPreferences _prefs;

  ThemeProvider(this._prefs) : _currentTheme = _darkTheme {
    _loadSettings();
  }

  ThemeData get currentTheme => _currentTheme;
  String get currentFont => _currentFont;

  static final ThemeData _lightTheme = ThemeData(
    primaryColor: const Color(0xFF1A2B3C),
    scaffoldBackgroundColor: Colors.white,
    colorScheme: ColorScheme.light(
      primary: const Color(0xFF1A2B3C),
      secondary: Colors.white,
      background: Colors.white,
      surface: Colors.white,
    ),
    useMaterial3: true,
  );

  static final ThemeData _darkTheme = ThemeData(
    primaryColor: const Color(0xFF1A2B3C),
    scaffoldBackgroundColor: const Color(0xFF1A2B3C),
    colorScheme: ColorScheme.dark(
      primary: const Color(0xFF1A2B3C),
      secondary: Colors.white,
      background: const Color(0xFF1A2B3C),
      surface: const Color(0xFF1A2B3C),
    ),
    useMaterial3: true,
  );

  void toggleTheme() {
    _currentTheme = _currentTheme == _darkTheme ? _lightTheme : _darkTheme;
    _prefs.setBool('isDarkMode', _currentTheme == _darkTheme);
    notifyListeners();
  }

  void setFont(String fontFamily) {
    _currentFont = fontFamily;
    _prefs.setString('font', fontFamily);
    notifyListeners();
  }

  TextStyle getTextStyle({double? size, FontWeight? weight, Color? color}) {
    final font = switch (_currentFont) {
      'Roboto' => GoogleFonts.roboto,
      'Poppins' => GoogleFonts.poppins,
      'Montserrat' => GoogleFonts.montserrat,
      'Lato' => GoogleFonts.lato,
      _ => GoogleFonts.roboto,
    };

    return font(
      fontSize: size,
      fontWeight: weight,
      color: color ?? (_currentTheme == _darkTheme ? Colors.white : Colors.black),
    );
  }

  void _loadSettings() {
    final isDarkMode = _prefs.getBool('isDarkMode') ?? true;
    _currentTheme = isDarkMode ? _darkTheme : _lightTheme;
    _currentFont = _prefs.getString('font') ?? 'Roboto';
  }
} 