import 'dart:math' as math;

class Distributions {
  static const int POINTS = 100;  // Number of points to plot

  static List<double> generateXPoints(double mean, double variance, String distribution) {
    double std = math.sqrt(variance);
    List<double> points = [];
    
    switch (distribution) {
      case 'normal':
      case 'gaussian':
        // Generate points from mean-4*std to mean+4*std
        for (int i = 0; i < POINTS; i++) {
          points.add(mean - 4 * std + (8 * std * i / (POINTS - 1)));
        }
      case 'laplacian':
      case 'laplace':
        // Generate points from mean-6*b to mean+6*b where b = std/sqrt(2)
        double b = std / math.sqrt(2);
        for (int i = 0; i < POINTS; i++) {
          points.add(mean - 6 * b + (12 * b * i / (POINTS - 1)));
        }
      case 'rayleigh':
        // Generate points from 0 to mean+4*std
        for (int i = 0; i < POINTS; i++) {
          points.add((mean + 4 * std) * i / (POINTS - 1));
        }
      case 'poisson':
        // Generate points from 0 to mean+4*std
        for (int i = 0; i < POINTS; i++) {
          points.add(i * (mean + 4 * std) / (POINTS - 1));
        }
      case 'binomial':
        // Generate integer points
        for (int i = 0; i < POINTS; i++) {
          points.add(i * (mean + 4 * std) / (POINTS - 1));
        }
      case 'exponential':
        // Generate points from 0 to mean+4*std
        for (int i = 0; i < POINTS; i++) {
          points.add(i * (mean + 4 * std) / (POINTS - 1));
        }
      case 'uniform':
        // Generate points from mean-sqrt(12*variance)/2 to mean+sqrt(12*variance)/2
        double range = math.sqrt(12 * variance) / 2;
        for (int i = 0; i < POINTS; i++) {
          points.add(mean - range + (2 * range * i / (POINTS - 1)));
        }
    }
    return points;
  }

  static List<double> calculatePDF(List<double> xPoints, double mean, double variance, String distribution) {
    List<double> yPoints = [];
    double std = math.sqrt(variance);
    
    switch (distribution) {
      case 'normal':
      case 'gaussian':
        for (double x in xPoints) {
          double y = (1 / (std * math.sqrt(2 * math.pi))) * 
                    math.exp(-math.pow(x - mean, 2) / (2 * variance));
          yPoints.add(y);
        }
      case 'laplacian':
      case 'laplace':
        double b = std / math.sqrt(2);  // Scale parameter
        for (double x in xPoints) {
          double y = (1 / (2 * b)) * math.exp(-math.abs(x - mean) / b);
          yPoints.add(y);
        }
      case 'rayleigh':
        double sigma = std;
        for (double x in xPoints) {
          if (x < 0) {
            yPoints.add(0);
          } else {
            double y = (x / (sigma * sigma)) * 
                      math.exp(-math.pow(x, 2) / (2 * sigma * sigma));
            yPoints.add(y);
          }
        }
      case 'poisson':
        for (double x in xPoints) {
          if (x < 0) {
            yPoints.add(0);
          } else {
            int k = x.round();
            double y = math.pow(mean, k) * math.exp(-mean) / 
                      factorial(k);
            yPoints.add(y);
          }
        }
      case 'binomial':
        int n = 20; // Fixed number of trials
        double p = mean / n; // Probability of success
        for (double x in xPoints) {
          if (x < 0 || x > n) {
            yPoints.add(0);
          } else {
            int k = x.round();
            double y = combinations(n, k) * 
                      math.pow(p, k) * 
                      math.pow(1 - p, n - k);
            yPoints.add(y);
          }
        }
      case 'exponential':
        double lambda = 1 / mean;
        for (double x in xPoints) {
          if (x < 0) {
            yPoints.add(0);
          } else {
            double y = lambda * math.exp(-lambda * x);
            yPoints.add(y);
          }
        }
      case 'uniform':
        double range = math.sqrt(12 * variance) / 2;
        double a = mean - range;
        double b = mean + range;
        for (double x in xPoints) {
          if (x < a || x > b) {
            yPoints.add(0);
          } else {
            yPoints.add(1 / (b - a));
          }
        }
    }
    return yPoints;
  }

  static List<double> calculateCDF(List<double> xPoints, double mean, double variance, String distribution) {
    List<double> yPoints = [];
    double std = math.sqrt(variance);
    
    switch (distribution) {
      case 'normal':
      case 'gaussian':
        for (double x in xPoints) {
          double z = (x - mean) / (std * math.sqrt(2));
          double y = 0.5 * (1 + erf(z));
          yPoints.add(y);
        }
      case 'laplacian':
      case 'laplace':
        double b = std / math.sqrt(2);  // Scale parameter
        for (double x in xPoints) {
          if (x < mean) {
            yPoints.add(0.5 * math.exp((x - mean) / b));
          } else {
            yPoints.add(1 - 0.5 * math.exp(-(x - mean) / b));
          }
        }
      case 'rayleigh':
        double sigma = std;
        for (double x in xPoints) {
          if (x < 0) {
            yPoints.add(0);
          } else {
            double y = 1 - math.exp(-math.pow(x, 2) / (2 * sigma * sigma));
            yPoints.add(y);
          }
        }
      case 'poisson':
        for (double x in xPoints) {
          if (x < 0) {
            yPoints.add(0);
          } else {
            int k = x.round();
            double sum = 0;
            for (int i = 0; i <= k; i++) {
              sum += math.pow(mean, i) * math.exp(-mean) / factorial(i);
            }
            yPoints.add(sum);
          }
        }
      case 'binomial':
        int n = 20; // Fixed number of trials
        double p = mean / n; // Probability of success
        for (double x in xPoints) {
          if (x < 0) {
            yPoints.add(0);
          } else if (x >= n) {
            yPoints.add(1);
          } else {
            int k = x.round();
            double sum = 0;
            for (int i = 0; i <= k; i++) {
              sum += combinations(n, i) * 
                    math.pow(p, i) * 
                    math.pow(1 - p, n - i);
            }
            yPoints.add(sum);
          }
        }
      case 'exponential':
        double lambda = 1 / mean;
        for (double x in xPoints) {
          if (x < 0) {
            yPoints.add(0);
          } else {
            double y = 1 - math.exp(-lambda * x);
            yPoints.add(y);
          }
        }
      case 'uniform':
        double range = math.sqrt(12 * variance) / 2;
        double a = mean - range;
        double b = mean + range;
        for (double x in xPoints) {
          if (x < a) {
            yPoints.add(0);
          } else if (x > b) {
            yPoints.add(1);
          } else {
            yPoints.add((x - a) / (b - a));
          }
        }
    }
    return yPoints;
  }

  static int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
  }

  static int combinations(int n, int k) {
    return factorial(n) ~/ (factorial(k) * factorial(n - k));
  }

  static double erf(double x) {
    // Approximation of the error function
    double t = 1.0 / (1.0 + 0.5 * x.abs());
    double tau = t * math.exp(-x * x - 1.26551223 +
        t * (1.00002368 +
            t * (0.37409196 +
                t * (0.09678418 +
                    t * (-0.18628806 +
                        t * (0.27886807 +
                            t * (-1.13520398 +
                                t * (1.48851587 +
                                    t * (-0.82215223 +
                                        t * 0.17087277)))))))));
    return x >= 0 ? 1 - tau : tau - 1;
  }
} 