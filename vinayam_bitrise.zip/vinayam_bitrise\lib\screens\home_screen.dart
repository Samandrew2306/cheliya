import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import 'package:fuzzy_string_matching/fuzzy_string_matching.dart';
import 'plot_screen.dart';
import 'package:string_similarity/string_similarity.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final SpeechToText _speechToText = SpeechToText();
  bool _speechEnabled = false;
  bool _isListening = false;
  String _lastWords = '';
  late AnimationController _controller;
  late Animation<Offset> _titleAnimation;
  
  final List<String> _distributions = [
    'normal',
    'gaussian',
    'rayleigh',
    'poisson',
    'binomial',
    'exponential',
    'uniform'
  ];

  String? _selectedDistribution;
  double? _mean;
  double? _variance;
  
  // Map of distribution names and their variations
  final Map<String, List<String>> _distributionVariations = {
    'normal': ['normal', 'normale', 'norman', 'norm'],
    'gaussian': ['gaussian', 'gauss', 'gowsian', 'gowshan'],
    'laplacian': ['laplacian', 'laplace', 'la place', 'la plus', 'laplase'],
    'rayleigh': ['rayleigh', 'relay', 'ray lee', 'raylee', 'really'],
    'poisson': ['poisson', 'poison', 'pois son', 'person', 'poison'],
    'binomial': ['binomial', 'binary', 'bi normal', 'bye normal', 'binominal'],
    'exponential': ['exponential', 'exponent', 'exponention', 'exponensial'],
    'uniform': ['uniform', 'uni form', 'unique form', 'uni formal']
  };

  @override
  void initState() {
    super.initState();
    _initSpeech();
    
    // Initialize animation controller
    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    
    // Create slide up animation for title
    _titleAnimation = Tween<Offset>(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    ));
    
    // Start the animation
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// Initialize speech recognition
  Future<void> _initSpeech() async {
    _speechEnabled = await _speechToText.initialize();
    setState(() {});
  }

  /// Start listening to speech
  Future<void> _startListening() async {
    await _speechToText.listen(
      onResult: _onSpeechResult,
      listenFor: const Duration(seconds: 30),
      partialResults: true,
      cancelOnError: true,
      listenMode: ListenMode.confirmation,
    );
    setState(() {
      _isListening = true;
    });
  }

  /// Stop listening to speech
  Future<void> _stopListening() async {
    await _speechToText.stop();
    setState(() {
      _isListening = false;
    });
  }

  /// Handle speech result
  void _onSpeechResult(SpeechRecognitionResult result) {
    setState(() {
      _lastWords = result.recognizedWords.toLowerCase();
      _processInput(_lastWords);
    });
  }

  /// Process speech input
  void _processInput(String input) {
    if (_selectedDistribution == null) {
      // Try to match distribution name
      String? matchedDistribution = _findClosestMatch(input, _distributionVariations.keys.toList());
      if (matchedDistribution != null) {
        setState(() {
          _selectedDistribution = matchedDistribution;
          _lastWords = 'Please specify the mean value';
        });
      }
    } else if (_mean == null) {
      // Try to extract mean value
      double? meanValue = _extractNumber(input);
      if (meanValue != null) {
        setState(() {
          _mean = meanValue;
          _lastWords = 'Please specify the variance value';
        });
      }
    } else if (_variance == null) {
      // Try to extract variance value
      double? varianceValue = _extractNumber(input);
      if (varianceValue != null) {
        setState(() {
          _variance = varianceValue;
          _plotDistribution();
        });
      }
    }
  }

  String? _findClosestMatch(String input, List<String> possibilities) {
    double highestSimilarity = 0;
    String? closestMatch;
    
    // First, check if the input exactly matches any distribution name
    for (var entry in _distributionVariations.entries) {
      if (entry.value.contains(input.toLowerCase())) {
        return entry.key;
      }
    }
    
    // If no exact match, try fuzzy matching with all variations
    for (var entry in _distributionVariations.entries) {
      for (String variation in entry.value) {
        double similarity = StringSimilarity.compareTwoStrings(
          input.toLowerCase(),
          variation.toLowerCase()
        );
        if (similarity > highestSimilarity && similarity > 0.6) {
          highestSimilarity = similarity;
          closestMatch = entry.key;
        }
      }
    }
    
    return closestMatch;
  }

  double? _extractNumber(String input) {
    RegExp regex = RegExp(r'(\d+\.?\d*)');
    Match? match = regex.firstMatch(input);
    if (match != null) {
      return double.tryParse(match.group(1)!);
    }
    return null;
  }

  void _plotDistribution() {
    if (_selectedDistribution != null && _mean != null && _variance != null) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => PlotScreen(
            distribution: _selectedDistribution!,
            mean: _mean!,
            variance: _variance!,
          ),
        ),
      );
    }
  }

  void _resetState() {
    setState(() {
      _selectedDistribution = null;
      _mean = null;
      _variance = null;
      _lastWords = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: themeProvider.currentTheme.primaryColor,
              ),
              child: Text(
                'Settings',
                style: themeProvider.getTextStyle(
                  size: 24,
                  weight: FontWeight.bold,
                ),
              ),
            ),
            ListTile(
              title: Text(
                'Toggle Theme',
                style: themeProvider.getTextStyle(),
              ),
              trailing: Icon(
                themeProvider.currentTheme == ThemeProvider._darkTheme
                    ? Icons.dark_mode
                    : Icons.light_mode,
              ),
              onTap: () {
                themeProvider.toggleTheme();
                Navigator.pop(context);
              },
            ),
            ExpansionTile(
              title: Text(
                'Change Font',
                style: themeProvider.getTextStyle(),
              ),
              children: [
                ListTile(
                  title: Text('Roboto', style: GoogleFonts.roboto()),
                  onTap: () => themeProvider.setFont('Roboto'),
                ),
                ListTile(
                  title: Text('Poppins', style: GoogleFonts.poppins()),
                  onTap: () => themeProvider.setFont('Poppins'),
                ),
                ListTile(
                  title: Text('Montserrat', style: GoogleFonts.montserrat()),
                  onTap: () => themeProvider.setFont('Montserrat'),
                ),
                ListTile(
                  title: Text('Lato', style: GoogleFonts.lato()),
                  onTap: () => themeProvider.setFont('Lato'),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          SlideTransition(
            position: _titleAnimation,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                'Distributions Plotter',
                style: themeProvider.getTextStyle(
                  size: 28,
                  weight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTapDown: (_) async {
                    if (!_isListening) {
                      await _startListening();
                    }
                  },
                  onTapUp: (_) async {
                    if (_isListening) {
                      await _stopListening();
                    }
                  },
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isListening ? Colors.red : themeProvider.currentTheme.primaryColor,
                    ),
                    child: Icon(
                      _isListening ? Icons.mic : Icons.mic_none,
                      size: 50,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  _lastWords.isEmpty
                      ? 'Tap and hold to speak'
                      : _lastWords,
                  style: themeProvider.getTextStyle(size: 16),
                  textAlign: TextAlign.center,
                ),
                if (_selectedDistribution != null) ...[
                  const SizedBox(height: 20),
                  Text(
                    'Distribution: $_selectedDistribution',
                    style: themeProvider.getTextStyle(size: 16),
                  ),
                  if (_mean != null)
                    Text(
                      'Mean: $_mean',
                      style: themeProvider.getTextStyle(size: 16),
                    ),
                  if (_variance != null)
                    Text(
                      'Variance: $_variance',
                      style: themeProvider.getTextStyle(size: 16),
                    ),
                ],
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _selectedDistribution != null
          ? FloatingActionButton(
              onPressed: _resetState,
              child: const Icon(Icons.refresh),
            )
          : null,
    );
  }
} 